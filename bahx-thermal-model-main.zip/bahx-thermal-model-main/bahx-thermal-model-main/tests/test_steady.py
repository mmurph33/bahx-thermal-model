"""Verification of the steady model (CLAUDE.md "Verification"; math doc Section 5.4).

Never loosen a tolerance to make a test pass; report the failure and its likely
cause instead (CLAUDE.md).

The constant-property test is self-contained: it builds its own parameters and
constant surrogates, so it runs without CoolProp and does not depend on the
team's base-case choices. The two variable-property tests use
``config.BASE_CASE`` and fail with a list of the missing keys until the TODO
values in ``src/config.py`` that the steady model needs are filled in.
"""

import numpy as np
import pytest

from src import config, correlations, properties, steady

# Keys of config.BASE_CASE that the steady model (properties, correlations and
# steady.py) reads. The transient/scenario keys are not needed here.
STEADY_KEYS = (
    "fluid", "p_h", "p_c", "T_h_in", "T_c_in", "mdot_h", "mdot_c",
    "L", "W",
    "s_h", "b_h", "t_fin_h", "l_h", "s_c", "b_c", "t_fin_c", "l_c",
    "t_sheet", "rho_m", "c_m", "k_f",
    "n_out", "bvp_tol", "bvp_max_nodes", "continuation_lams",
    "fit_degree", "fit_n_points", "fit_T_margin", "fit_max_rel_err",
)


def _base_case_params():
    """config.BASE_CASE copy for the variable-property tests, tight bvp_tol.

    Fails (not skips) with the missing keys if a steady-model TODO is still None.
    """
    params = dict(config.BASE_CASE)
    missing = [key for key in STEADY_KEYS if params.get(key) is None]
    if missing:
        pytest.fail(
            "config.BASE_CASE still has TODO (None) values needed by the steady "
            "model: " + ", ".join(missing)
        )
    # solve_bvp controls a relative residual, not the solution error, so a tight
    # tolerance is needed to check closure and agreement to ~1e-5.
    params["bvp_tol"] = 1.0e-8
    return params


def _synthetic_params():
    """Explicit test inputs for the constant-property test (no CoolProp)."""
    params = dict(config.BASE_CASE)
    params.update(
        T_h_in=300.0, T_c_in=235.0,
        mdot_h=0.1, mdot_c=0.1,
        L=1.0,  # overwritten per case so that NTU is the value we want
        W=1.0,
        s_h=1.525e-3, b_h=6.25e-3, t_fin_h=1.02e-4, l_h=3.175e-3,
        s_c=1.525e-3, b_c=6.25e-3, t_fin_c=1.02e-4, l_c=3.175e-3,
        t_sheet=1.0e-3, rho_m=2700.0, c_m=880.0, k_f=180.0,
        n_out=501, bvp_tol=1.0e-8, bvp_max_nodes=10000,
        continuation_lams=(0.0, 0.25, 0.5, 0.75, 1.0),
    )
    return params


# (cp_h, cp_c, NTU) with mdot_h = mdot_c = 0.1 kg/s, so C = 0.1 * cp.
#   hot_is_cmin:  C_h = 250 < C_c = 500 W/K, C_r = 0.5, NTU (1 - C_r) = 3
#   cold_is_cmin: C_h = 500 > C_c = 250 W/K, C_r = 0.5, NTU (1 - C_r) = 3
#   balanced:     C_h = C_c = 250 W/K exactly, C_r = 1 (the k -> 0 branch), NTU = 4
CASES = {
    "hot_is_cmin": (2500.0, 5000.0, 6.0),
    "cold_is_cmin": (5000.0, 2500.0, 6.0),
    "balanced": (2500.0, 2500.0, 4.0),
}


@pytest.mark.parametrize("case", ["hot_is_cmin", "cold_is_cmin", "balanced"])
def test_constant_property_matches_epsilon_ntu(case):
    """Constant-property BVP solution matches the analytical epsilon-NTU solution.

    CLAUDE.md check 1 / math doc Section 5.4 item 1: with constant properties
    the numerical effectiveness and profiles match Eq 13 and Eq 11 (here the
    unified form in steady.analytical_profiles) to solver tolerance,
    including C_r = 1. Run for hot = C_min, cold = C_min and balanced flow,
    since the analytical formulas differ between these cases.
    """
    cp_h, cp_c, NTU = CASES[case]
    mu, k, rho = 1.2e-5, 0.04, 20.0  # the same for both streams; only cp differs

    # 1. Constant surrogates (no CoolProp) and constant conductances.
    params = _synthetic_params()
    props = {
        "h": properties.constant_surrogate(cp_h, mu, k, rho, 200.0, 320.0),
        "c": properties.constant_surrogate(cp_c, mu, k, rho, 200.0, 320.0),
    }
    geom = correlations.exchanger_geometry(params)
    a_h, a_c = correlations.conductances(
        250.0, 250.0, params["mdot_h"], params["mdot_c"], params, props, geom
    )
    U_prime = float(correlations.overall_conductance(a_h, a_c))

    # 2. Choose L so that NTU = U' L / C_min takes the demanding value above.
    C_h = params["mdot_h"] * cp_h
    C_c = params["mdot_c"] * cp_c
    C_min, C_max = min(C_h, C_c), max(C_h, C_c)
    C_r = C_min / C_max
    L = NTU * C_min / U_prime
    params["L"] = L

    # 3. Numerical solution and the analytical solution on the same grid.
    s = steady.solve_steady(params, props)
    T_h_in, T_c_in = params["T_h_in"], params["T_c_in"]
    T_h_ex, T_c_ex = steady.analytical_profiles(
        s["x"], L, T_h_in, T_c_in, C_h, C_c, U_prime
    )

    # 4. Profiles in dimensionless form, theta = (T - T_c_in)/(T_h_in - T_c_in).
    dT = T_h_in - T_c_in
    assert np.max(np.abs((s["T_h"] - T_h_ex) / dT)) < 1e-5
    assert np.max(np.abs((s["T_c"] - T_c_ex) / dT)) < 1e-5

    # 5. Effectiveness against Eq 13.
    eps_num = C_h * (T_h_in - s["T_h"][-1]) / (C_min * dT)
    assert abs(eps_num - steady.effectiveness(NTU, C_r)) < 1e-6

    # 6. Largest stream-to-stream difference. Its VALUE is Eq 14,
    #    (1 - C_r)/(1 - C_r E) (T_h_in - T_c_in) with E = exp(-NTU (1 - C_r)),
    #    whichever stream is C_min; its LOCATION is the warm end (x = 0) when
    #    hot is C_min and the cold end (x = L) when cold is C_min. For balanced
    #    flow the difference is constant, 1/(1 + NTU).
    theta_diff = (s["T_h"] - s["T_c"]) / dT
    if C_r == 1.0:
        expected_max = 1.0 / (1.0 + NTU)
    else:
        E = np.exp(-NTU * (1.0 - C_r))
        expected_max = (1.0 - C_r) / (1.0 - C_r * E)
    assert abs(np.max(theta_diff) - expected_max) < 1e-5
    if case == "hot_is_cmin":
        assert np.argmax(theta_diff) == 0
    elif case == "cold_is_cmin":
        assert np.argmax(theta_diff) == len(theta_diff) - 1


def test_energy_closure():
    """Hot duty, cold duty and the integrated heat flow agree.

    CLAUDE.md check 2 / math doc Section 5.4 item 2, Eq 16:
    Q_h = Q_c = integral of U'(T_h - T_c) dx, for the VARIABLE-property base
    case (with constant properties the check passes trivially).
    """
    # 1. Variable-property base case; the enthalpy surrogate is the integral of
    #    the cp surrogate, otherwise closure would be stuck at the fit error.
    params = _base_case_params()
    props = properties.build_surrogates(params)

    # 2. Solve and compute the three duties.
    s = steady.solve_steady(params, props)
    duty = steady.energy_balance(s, params, props)

    # 3. Closure of all three expressions of Eq 16.
    assert duty["closure_hc"] < 1e-4  # |Q_h - Q_c| / Q_h
    assert duty["closure_int"] < 1e-4  # |Q_h - Q_int| / Q_h

    # 4. Sanity: 0 < Q < the most either stream could exchange. The hot stream
    #    cannot be cooled below T_c_in, nor the cold stream heated above T_h_in.
    T_h_in, T_c_in = params["T_h_in"], params["T_c_in"]
    Q_max_hot = params["mdot_h"] * (
        properties.enthalpy(props["h"], T_h_in) - properties.enthalpy(props["h"], T_c_in)
    )
    Q_max_cold = params["mdot_c"] * (
        properties.enthalpy(props["c"], T_h_in) - properties.enthalpy(props["c"], T_c_in)
    )
    assert 0.0 < duty["Q_h"] < min(Q_max_hot, Q_max_cold)


def test_collocation_matches_shooting():
    """Collocation and shooting give the same variable-property solution.

    From math doc Section 5.4 item 3; this check is NOT in CLAUDE.md's
    verification list yet (flagged; added at the team's request).
    Two independent methods for the same BVP (Eq 6-8): solve_bvp collocation
    (Section 5.1) and solve_ivp + brentq shooting (Section 5.2, Eq 24).
    """
    # 1. Variable-property base case, both methods on the same output grid.
    params = _base_case_params()
    props = properties.build_surrogates(params)
    s_col = steady.solve_steady(params, props)
    s_sh = steady.solve_steady_shooting(params, props)

    # 2. Profiles agree.
    assert np.max(np.abs(s_col["T_h"] - s_sh["T_h"])) < 1e-3  # K
    assert np.max(np.abs(s_col["T_c"] - s_sh["T_c"])) < 1e-3  # K

    # 3. Cold outlet (the shooting unknown sigma).
    assert abs(s_col["T_c"][0] - s_sh["T_c"][0]) < 1e-4  # K

    # 4. Duty.
    Q_col = steady.energy_balance(s_col, params, props)["Q_h"]
    Q_sh = steady.energy_balance(s_sh, params, props)["Q_h"]
    assert abs(Q_col - Q_sh) / Q_col < 1e-5
    # Note: if this fails at large NTU (1 - C_r), suspect shooting first (its
    # known weakness, Section 5.2): tighten its solve_ivp tolerances before
    # blaming collocation.
